using UnityEngine;
using UnityEngine.UI;
using TMPro;

[System.Serializable]
public class DialogueOption
{
    [TextArea(2, 4)]
    public string playerResponse;     // Текст ответа игрока
    [TextArea(2, 4)]
    public string npcReply;           // Что NPC скажет в ответ
    public Color objectColor = Color.white; // Новый параметр — цвет, который меняется при выборе
}

public class DialogueChoice : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject dialoguePanel;
    public TextMeshProUGUI dialogueText;
    public Button[] optionButtons; // 3 кнопки
    public GameObject pressEHint;

    [Header("Dialogue Data")]
    [TextArea(2, 4)]
    public string startDialogue; // первая фраза NPC
    public DialogueOption[] options; // список вариантов

    [Header("Target Object")]
    public Renderer targetRenderer; // объект, чей цвет будет меняться

    private bool playerInRange = false;
    private bool dialogueActive = false;

    void Update()
    {
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (!dialogueActive)
                StartDialogue();
            else
                EndDialogue();
        }
    }

    void StartDialogue()
    {
        dialogueActive = true;
        dialoguePanel.SetActive(true);
        pressEHint.SetActive(false);

        dialogueText.text = startDialogue;

        // Отображаем варианты
        for (int i = 0; i < optionButtons.Length; i++)
        {
            if (i < options.Length)
            {
                optionButtons[i].gameObject.SetActive(true);
                int index = i; // локальная копия для замыкания
                optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = options[i].playerResponse;

                optionButtons[i].onClick.RemoveAllListeners();
                optionButtons[i].onClick.AddListener(() => SelectOption(index));
            }
            else
            {
                optionButtons[i].gameObject.SetActive(false);
            }
        }
    }

    void SelectOption(int index)
    {
        // Показываем реакцию NPC
        dialogueText.text = options[index].npcReply;

        // Меняем цвет объекта, если он указан
        if (targetRenderer != null)
            targetRenderer.material.color = options[index].objectColor;

        // Скрываем кнопки после выбора
        foreach (Button btn in optionButtons)
            btn.gameObject.SetActive(false);

        // Можно закрыть диалог через пару секунд
        Invoke(nameof(EndDialogue), 2.5f);
    }

    void EndDialogue()
    {
        dialogueActive = false;
        dialoguePanel.SetActive(false);
        pressEHint.SetActive(true);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            pressEHint.SetActive(true);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            pressEHint.SetActive(false);
            dialoguePanel.SetActive(false);
            dialogueActive = false;

            for (int i = 0; i < optionButtons.Length; i++)
            {
                if (i < options.Length)
                    optionButtons[i].gameObject.SetActive(false);
            }
        }
    }
}
