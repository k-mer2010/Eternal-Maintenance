using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Iteractions1 : MonoBehaviour
{
    public GameObject dialogueUI1;           // Панель диалога
    public TMPro.TextMeshProUGUI textUI1;    // Текстовый элемент TMP
    public GameObject pressEHint1;           // Подсказка "Нажмите E"

    public string[] dialogueLines1;          // Список фраз диалога

    private int currentLine1 = 0;
    private bool playerInRange1 = false;
    private bool dialogueActive1 = false;
    void Update()
    {
        if (playerInRange1 && Input.GetKeyDown(KeyCode.E))
        {
            if (!dialogueActive1)
            {
                Destroy(gameObject);
            }
        }
    }
    void StartDialogue1()
    {
        dialogueActive1 = true;
        currentLine1 = 0;
        dialogueUI1.SetActive(true);
        pressEHint1.SetActive(false);
        ShowLine1();
    }
    void NextLine1()
    {
        currentLine1++;

        if (currentLine1 < dialogueLines1.Length)
        {
            ShowLine1();
        }
        else
        {
            EndDialogue1();
        }
    }

    void ShowLine1()
    {
        if (textUI1 != null)
            textUI1.text = dialogueLines1[currentLine1];
    }

    void EndDialogue1()
    {
        dialogueActive1 = false;
        dialogueUI1.SetActive(false);
        pressEHint1.SetActive(true);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange1 = true;
            pressEHint1.SetActive(true);
        }
    }
    // Start is called before the first frame update
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange1 = false;
            pressEHint1.SetActive(false);
            dialogueUI1.SetActive(false);
            dialogueActive1 = false;
        }
    }

    // Update is called once per frame
}
