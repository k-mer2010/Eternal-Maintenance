using UnityEngine;
using TMPro;

public class Ehint: MonoBehaviour
{
    public Transform target;          // объект, над которым показывать подсказку
    public Vector3 offset = new Vector3(0, 2f, 0); // высота над головой
    public Camera mainCamera;         // основная камера
    private RectTransform rectTransform;

    void Start()
    {
        rectTransform = GetComponent<RectTransform>();
        if (mainCamera == null)
            mainCamera = Camera.main;
    }

    void Update()
    {
        if (target == null) return;

        // Переводим мировые координаты в экранные
        Vector3 screenPos = mainCamera.WorldToScreenPoint(target.position + offset);

        // Двигаем UI элемент в позиции экрана
        rectTransform.position = screenPos;
    }
}
