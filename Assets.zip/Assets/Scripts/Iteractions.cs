using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Iteractions : MonoBehaviour
{
    public GameObject dialogueUI;           // Панель диалога
    public TMPro.TextMeshProUGUI textUI;    // Текстовый элемент TMP
    public GameObject pressEHint;           // Подсказка "Нажмите E"

    public string[] dialogueLines;          // Список фраз диалога

    private int currentLine = 0;
    private bool playerInRange = false;
    private bool dialogueActive = false;
    void Update()
    {
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (!dialogueActive)
            {
                StartDialogue();
            }
            else
            {
                NextLine();
            }
        }
    }
    void StartDialogue()
    {
        dialogueActive = true;
        currentLine = 0;
        dialogueUI.SetActive(true);
        pressEHint.SetActive(false);
        ShowLine();
    }
    void NextLine()
    {
        currentLine++;

        if (currentLine < dialogueLines.Length)
        {
            ShowLine();
        }
        else
        {
            EndDialogue();
        }
    }

    void ShowLine()
    {
        if (textUI != null)
            textUI.text = dialogueLines[currentLine];
    }

    void EndDialogue()
    {
        dialogueActive = false;
        dialogueUI.SetActive(false);
        pressEHint.SetActive(true);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            pressEHint.SetActive(true);
        }
    }
    // Start is called before the first frame update
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            pressEHint.SetActive(false);
            dialogueUI.SetActive(false);
            dialogueActive = false;
        }
    }

    // Update is called once per frame
}
